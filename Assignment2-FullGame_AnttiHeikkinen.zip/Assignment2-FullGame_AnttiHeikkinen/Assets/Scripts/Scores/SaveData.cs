﻿using System;
using System.Collections.Generic;

[Serializable]
public class SaveData
{
    public List<HighScoreData> HighScores;	
}
