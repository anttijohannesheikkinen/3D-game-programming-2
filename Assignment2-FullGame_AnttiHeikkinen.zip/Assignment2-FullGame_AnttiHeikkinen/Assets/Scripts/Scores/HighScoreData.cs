﻿using System;
using UnityEngine;

[Serializable]
public class HighScoreData
{
    public string PlayerName;
    public int Score;
}
