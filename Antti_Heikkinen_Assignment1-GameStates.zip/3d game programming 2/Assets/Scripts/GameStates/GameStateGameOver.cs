﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameStateGameOver : GameStateBase {

	// Use this for initialization
	protected new void Start () {
        stateName = "GameOver";
        base.Start();
    }
	
	// Update is called once per frame
	protected new void Update () {
		
	}
}
